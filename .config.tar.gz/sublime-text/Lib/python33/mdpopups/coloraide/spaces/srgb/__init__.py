"""SRGB color class."""
