#!/bin/bash
source ~/.bashrc  # or your shell's config file
rofi -show drun