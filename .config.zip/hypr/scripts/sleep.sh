#!/bin/bash 
swayidle -w timeout 10 'swaylock --grace 5'