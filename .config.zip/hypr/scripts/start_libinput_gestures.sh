#!/bin/bash
libinput-gestures-setup start